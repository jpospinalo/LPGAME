package uk.ac.imperial.lpgdash.gui;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

public class UtilityDistributionChart implements TimeSeriesChart {

	@Override
	public ChartPanel getPanel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JFreeChart getChart() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void redraw(int t) {
		// TODO Auto-generated method stub

	}

}
