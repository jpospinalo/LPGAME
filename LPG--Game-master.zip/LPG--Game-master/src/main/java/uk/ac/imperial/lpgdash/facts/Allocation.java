package uk.ac.imperial.lpgdash.facts;

public enum Allocation {
	RATION, RANDOM, LC_FIXED, LC_F1a, LC_F1b, LC_F1c, LC_F2, LC_F3, LC_F4, LC_F5, LC_F6, LC_SO, QUEUE
}
