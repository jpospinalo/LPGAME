package uk.ac.imperial.lpgdash.allocators.canons;

public enum Canon {
	F1a, F1b, F1c, F2, F3, F4, F5, F6
}