package uk.ac.imperial.lpgdash;

public class Globals {
	public static double pDetectInstitutionalCheat = 1.0;
	public static double pDetectPhysicalCheat = 1.0;
}
