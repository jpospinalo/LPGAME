package uk.ac.imperial.lpgdash.facts;

public enum Role {
	PROSUMER, HEAD
}
