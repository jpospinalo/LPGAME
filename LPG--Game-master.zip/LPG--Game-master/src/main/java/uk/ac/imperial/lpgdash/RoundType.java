package uk.ac.imperial.lpgdash;

public enum RoundType {
	INIT, DEMAND, APPROPRIATE
}
