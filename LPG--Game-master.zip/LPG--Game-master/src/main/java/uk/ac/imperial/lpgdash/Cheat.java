package uk.ac.imperial.lpgdash;

public enum Cheat {
	PROVISION, DEMAND, APPROPRIATE
}
